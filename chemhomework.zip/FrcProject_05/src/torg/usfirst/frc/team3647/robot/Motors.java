package torg.usfirst.frc.team3647.robot;

import edu.wpi.first.wpilibj.Spark;

public class Motors 
{
	public static Spark leftMotor = new Spark(2);
	public static Spark rightMotor = new Spark(1);
}

